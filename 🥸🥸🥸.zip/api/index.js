import express from "express";
import axios from "axios";
import fs from "fs";
import protobuf from "protobufjs";
import { encrypt_api, Encrypt_ID } from "../byte.js";

const app = express();

let Info = null;

// Load protobuf
(async () => {
  const root = await protobuf.load("visit_count.proto");
  Info = root.lookupType("proto.Info");
})();

function loadTokens(region) {
  let file = "token_bd.json";
  if (region === "IND") file = "token_ind.json";
  if (["BR","US","SAC","NA"].includes(region)) file = "token_br.json";

  const json = JSON.parse(fs.readFileSync(file));
  return json.map(x => x.token);
}

function getURL(region) {
  if (region === "IND")
    return "https://client.ind.freefiremobile.com/GetPlayerPersonalShow";
  if (["BR","US","SAC","NA"].includes(region))
    return "https://client.us.freefiremobile.com/GetPlayerPersonalShow";
  return "https://clientbp.ggblueshark.com/GetPlayerPersonalShow";
}

app.get("/:server/:uid", async (req, res) => {
  const server = req.params.server.toUpperCase();
  const uid = req.params.uid;

  const tokens = loadTokens(server);
  if (!tokens.length) return res.json({ error: "No tokens found" });

  const packet = encrypt_api("08" + Encrypt_ID(uid) + "1801");
  const buffer = Buffer.from(packet, "hex");

  let success = 0;
  let player = null;

  for (let token of tokens) {
    try {
      const r = await axios.post(getURL(server), buffer, {
        responseType: "arraybuffer",
        headers: {
          "Authorization": "Bearer " + token,
          "ReleaseVersion": "OB52",
          "X-GA": "v1 1"
        }
      });

      if (!player) {
        const decoded = Info.decode(new Uint8Array(r.data));
        player = decoded.AccountInfo;
      }

      success++;
    } catch {}
  }

  res.json({
    success,
    uid,
    nickname: player?.PlayerNickname || "",
    likes: player?.Likes || 0,
    level: player?.Levels || 0,
    region: player?.PlayerRegion || "",
    tokens_used: tokens.length
  });
});

export default app;